<?php if ( ! defined( 'ABSPATH' ) ) exit; 

//Place custom code here


?>